<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <title>{{ config('app.name', 'Laravel') }}</title>

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@1,900&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

        <!-- AlpineJS (Head) -->
        <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

        <style>
            *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

            :root {
                --navy: #0F172A;
                --gold: #D4AF37;
                --gold-light: #F4E7B3;
                --gold-dark: #B8860B;
                --silk: #F8FAFC;
            }

            body {
                font-family: 'Plus Jakarta Sans', sans-serif;
                background: var(--silk);
                background-image: 
                    radial-gradient(circle at top right, rgba(212, 175, 55, 0.08), transparent 40%),
                    radial-gradient(circle at bottom left, rgba(15, 23, 42, 0.05), transparent 40%);
                min-height: 100vh;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                padding: 1.5rem;
                color: var(--navy);
                -webkit-font-smoothing: antialiased;
                overflow-x: hidden;
            }

            .page-wrapper {
                width: 100%;
                max-width: 440px;
                display: flex;
                flex-direction: column;
                align-items: center;
                animation: fadeInUp 0.8s cubic-bezier(0.22, 1, 0.36, 1);
            }

            @keyframes fadeInUp {
                from { opacity: 0; transform: translateY(20px); }
                to { opacity: 1; transform: translateY(0); }
            }

            /* Logo Header - Refined */
            .logo-header {
                margin-bottom: 2rem;
                display: flex;
                flex-direction: column;
                align-items: center;
                z-index: 10;
            }

            .logo-glass {
                background: white;
                width: 72px;
                height: 72px;
                border-radius: 1.5rem;
                display: flex;
                align-items: center;
                justify-content: center;
                box-shadow: 0 15px 35px -10px rgba(0,0,0,0.1);
                border: 1px solid rgba(212, 175, 55, 0.15);
                margin-bottom: 1.25rem;
                transition: all 0.5s ease;
            }

            .logo-text {
                text-align: center;
            }

            .logo-text h2 {
                color: var(--navy);
                font-family: 'Playfair Display', serif;
                font-style: italic;
                font-weight: 900;
                font-size: 1.5rem;
                text-transform: uppercase;
                letter-spacing: 0.4em;
                line-height: 1;
                margin: 0;
            }

            .logo-text p {
                color: var(--gold-dark);
                font-weight: 800;
                font-size: 0.55rem;
                text-transform: uppercase;
                letter-spacing: 0.3em;
                margin-top: 0.5rem;
                opacity: 0.8;
            }

            /* Card */
            .card {
                background: rgba(255, 255, 255, 0.85);
                backdrop-filter: blur(20px);
                -webkit-backdrop-filter: blur(20px);
                border: 1px solid rgba(255, 255, 255, 0.5);
                box-shadow: 0 30px 60px -12px rgba(15, 23, 42, 0.12);
                border-radius: 2rem;
                width: 100%;
                max-width: 400px;
                padding: 2rem 1.5rem;
                position: relative;
            }

            .card-header {
                text-align: center;
                margin-bottom: 1.5rem;
            }

            .card-title {
                font-family: 'Plus Jakarta Sans', sans-serif;
                font-weight: 800;
                font-size: 1.1rem;
                color: var(--navy);
                letter-spacing: -0.01em;
                text-transform: uppercase;
            }

            .card-subtitle {
                font-size: 0.75rem;
                font-weight: 600;
                color: #64748b;
                margin-top: 0.25rem;
            }

            /* Inputs */
            .field-label {
                display: block;
                font-size: 0.65rem;
                font-weight: 800;
                color: var(--gold-dark);
                text-transform: uppercase;
                letter-spacing: 0.15em;
                margin-bottom: 0.5rem;
            }

            .input-wrapper {
                position: relative;
                margin-bottom: 1.25rem;
            }

            input[type="text"], input[type="password"], input[type="email"] {
                width: 100%;
                background: #f8fafc;
                border: 1.5px solid #e2e8f0;
                border-radius: 1rem;
                padding: 0.875rem 1rem 0.875rem 3.5rem;
                font-family: 'Plus Jakarta Sans', sans-serif;
                font-weight: 700;
                font-size: 0.95rem;
                color: var(--navy);
                outline: none;
                transition: all 0.3s ease;
            }

            input[type="text"]:focus {
                border-color: var(--gold);
                box-shadow: 0 0 0 4px rgba(212, 175, 55, 0.1);
            }

            .input-prefix {
                position: absolute;
                left: 1.25rem;
                top: 50%;
                transform: translateY(-50%);
                font-weight: 800;
                color: var(--gold-dark);
                font-size: 0.95rem;
            }

            /* OTP refined */
            .otp-grid {
                display: flex;
                justify-content: center;
                gap: 0.5rem;
                margin-bottom: 1.5rem;
                width: 100%;
            }

            .otp-input {
                width: 13%;
                max-width: 44px;
                aspect-ratio: 1;
                background: #f8fafc;
                border: 2px solid #e2e8f0;
                border-radius: 0.85rem;
                text-align: center;
                font-size: 1.5rem;
                font-weight: 800;
                color: var(--navy);
                outline: none;
                padding: 0;
                transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
                display: flex;
                align-items: center;
                justify-content: center;
                line-height: normal;
            }

            .otp-input:focus {
                border-color: var(--gold);
                background: white;
                box-shadow: 0 0 0 4px rgba(212, 175, 55, 0.15);
                transform: scale(1.05);
            }

            /* Premium Button - Fixed Sizing */
            .btn-premium {
                height: 3.25rem;
                width: 100%;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 0.5rem;
                background: var(--navy);
                color: white;
                font-weight: 800;
                font-size: 0.85rem;
                text-transform: uppercase;
                letter-spacing: 0.1em;
                border: none;
                border-radius: 1rem;
                cursor: pointer;
                transition: all 0.3s ease;
                box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.2);
            }

            .btn-premium:hover {
                background: #1e293b;
                transform: translateY(-2px);
            }

            .btn-premium svg {
                width: 1.25rem;
                height: 1.25rem;
                flex-shrink: 0;
            }

            .btn-text-link {
                color: var(--gold-dark);
                font-size: 0.7rem;
                font-weight: 800;
                text-transform: uppercase;
                letter-spacing: 0.1em;
                background: none;
                border: none;
                cursor: pointer;
                margin-top: 1rem;
                opacity: 0.8;
            }

            .btn-text-link:hover { opacity: 1; color: var(--navy); }

            /* Feedback */
            .msg-box {
                margin-top: 1rem;
                padding: 0.875rem;
                border-radius: 0.75rem;
                font-size: 0.8rem;
                font-weight: 700;
                text-align: center;
                display: none;
            }
            .msg-box.success { background: #dcfce7; color: #166534; display: block; }
            .msg-box.error { background: #fee2e2; color: #991b1b; display: block; }

            .phone-display {
                font-weight: 800;
                color: var(--navy);
                font-size: 1rem;
                margin: 0.5rem 0 1rem 0;
                display: block;
            }

            /* Footer */
            .page-footer {
                margin-top: 2.5rem;
                font-size: 0.6rem;
                font-weight: 800;
                text-transform: uppercase;
                letter-spacing: 0.4em;
                color: var(--navy);
                opacity: 0.3;
            }

            /* Responsive Adjustments */
            @media (max-width: 480px) {
                body {
                    padding: 1rem;
                }
                
                .card {
                    padding: 2rem 1.25rem;
                    border-radius: 1.5rem;
                }

                .logo-glass {
                    width: 64px;
                    height: 64px;
                }

                .logo-text h2 {
                    font-size: 1.25rem;
                    letter-spacing: 0.3em;
                }

                .otp-grid {
                    gap: 0.35rem;
                }

                .otp-input {
                    width: 14%;
                    font-size: 1.25rem;
                    border-radius: 0.65rem;
                }

                .btn-premium {
                    height: 3rem;
                    font-size: 0.8rem;
                }
            }

            @media (max-width: 360px) {
                .otp-grid {
                    gap: 0.25rem;
                }
                .otp-input {
                    width: 15%;
                    font-size: 1.1rem;
                }
            }

            [x-cloak] { display: none !important; }
        </style>
    </head>
    <body>
        <div class="page-wrapper">
            <header class="logo-header">
                <div class="logo-glass">
                    <x-application-logo />
                </div>
                <div class="logo-text">
                    <h2>B O T O</h2>
                    <p>Delphi Premium</p>
                </div>
            </header>

            <div class="card">
                <div class="card-content">
                    {{ $slot }}
                </div>
            </div>

            <p class="page-footer">B O   T O   D E L P I   &bull;   2 0 2 6</p>
        </div>
    </body>
</html>